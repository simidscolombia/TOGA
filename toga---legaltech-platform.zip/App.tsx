
import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import { Card, Button, Modal, PremiumLock, MarkdownRenderer, TogadoCompanion, VoiceRecorder } from './components/UIComponents';
import { generateLegalDocumentStream, compareJurisprudence } from './services/geminiService';
import { MOCK_USER, MOCK_CASES, MOCK_EVENTS, MOCK_POSTS, JURISPRUDENCE_MOCK_DB } from './constants';
import { User, DocType } from './types';
import { 
  Menu, Bell, Search as SearchIcon, FileText, 
  Calendar as CalIcon, MessageSquare, ThumbsUp, Send, Check,
  PenTool, Library, Copy, FileDown, Trash2, Printer
} from 'lucide-react';

function App() {
  const [activeView, setActiveView] = useState('dashboard');
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  
  // --- Persistence: User State ---
  const [user, setUser] = useState<User>(() => {
    const savedUser = localStorage.getItem('toga_user');
    return savedUser ? JSON.parse(savedUser) : MOCK_USER;
  });

  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  // Save user changes to localStorage
  useEffect(() => {
    localStorage.setItem('toga_user', JSON.stringify(user));
  }, [user]);

  // --- Upgrade Handler ---
  const handleUpgrade = () => {
    // Simulate payment process with Wompi (Conceptual)
    setTimeout(() => {
      setUser(prev => ({ ...prev, role: 'PREMIUM' }));
      setShowUpgradeModal(false);
      alert("¡Pago exitoso! Bienvenido a Toga Premium.");
    }, 1500);
  };

  // --- Togado Knowledge Base ---
  const TOGADO_KNOWLEDGE_BASE = {
    // Sidebar
    'sidebar': { 
        title: 'Barra de Navegación', 
        description: 'Tu centro de mando. Desde aquí accedes a todas las herramientas jurídicas.',
        tip: 'En dispositivos móviles, este menú se oculta automáticamente para darte más espacio.'
    },
    'nav-dashboard': { 
        title: 'Inicio / Dashboard', 
        description: 'Panel de control con tus estadísticas vitales y alertas.', 
        tip: 'Revisa este panel cada mañana. Si tienes vencimientos en rojo, dales prioridad absoluta.' 
    },
    'nav-search': { 
        title: 'Buscador Semántico', 
        description: 'Motor de búsqueda IA que entiende el contexto, no solo palabras clave.', 
        tip: 'En lugar de "tutela salud", intenta buscar "sentencias sobre negación de medicamentos vitales".' 
    },
    'nav-library': { 
        title: 'Biblioteca', 
        description: 'Repositorio seguro para tus expedientes y sentencias favoritas.', 
        tip: 'Organiza tus carpetas por año o por tipo de proceso para facilitar auditorías futuras.' 
    },
    'nav-calendar': { 
        title: 'Agenda', 
        description: 'Calendario especializado para audiencias y términos procesales.', 
        tip: 'Usa la sincronización para recibir alertas de audiencias directamente en tu celular.' 
    },
    'nav-drafter': { 
        title: 'Redactor IA (Pro)', 
        description: 'Generador automático de documentos legales basado en tus hechos.', 
        tip: 'Sé muy detallado con las fechas y nombres en los hechos. La IA es tan buena como la información que recibe.' 
    },
    'nav-comparator': { 
        title: 'Comparador (Pro)', 
        description: 'Analiza dos textos legales para encontrar contradicciones o líneas jurisprudenciales.', 
        tip: 'Perfecto para contrastar sentencias de primera y segunda instancia antes de una casación.' 
    },
    'nav-community': { 
        title: 'Comunidad', 
        description: 'Foro para conectar con colegas y resolver dudas complejas.', 
        tip: 'Si tienes un caso éticamente delicado, usa la opción "Anónimo" para pedir consejo sin riesgos.' 
    },
    'nav-profile': { 
        title: 'Mi Perfil', 
        description: 'Gestiona tu cuenta, suscripción y métricas de reputación.', 
        tip: 'Completar tu perfil con foto y especialidad aumenta tu visibilidad ante posibles clientes en la plataforma.' 
    },
    'nav-logout': { 
        title: 'Cerrar Sesión', 
        description: 'Finaliza tu sesión actual de forma segura.', 
        tip: 'Si usas un computador compartido (ej. en juzgados), siempre cierra sesión aquí.' 
    },

    // Header
    'header-notifications': { 
        title: 'Notificaciones', 
        description: 'Alertas sobre cambios en tus casos o interacciones en la comunidad.', 
        tip: 'Configura qué alertas recibir para no saturarte de información irrelevante.' 
    },
    'header-profile': { 
        title: 'Usuario', 
        description: 'Acceso rápido a tu configuración personal.', 
        tip: 'Aquí verás tu insignia de "Verificado" cuando alcances 1000 puntos de reputación.' 
    },
    
    // Dashboard Elements
    'welcome-banner': { 
        title: 'Resumen Diario', 
        description: 'Tu asistente personal que resume lo más urgente del día.', 
        tip: 'Si tu reputación baja, participa más en la comunidad respondiendo dudas para subirla.' 
    },
    'stats-grid': { 
        title: 'Métricas', 
        description: 'Indicadores de rendimiento de tu firma o práctica.', 
        tip: 'Monitorea el número de "Casos Activos" para no exceder tu capacidad operativa.' 
    },
    
    // Search Elements
    'search-input': { 
        title: 'Barra de Búsqueda', 
        description: 'Escribe tu consulta jurídica en lenguaje natural.', 
        tip: 'Puedes pegar un fragmento de una demanda y pedir jurisprudencia relacionada.' 
    },
    'search-results': { 
        title: 'Resultados', 
        description: 'Lista de sentencias y leyes que coinciden con tu búsqueda.', 
        tip: 'Las sentencias de la Corte Constitucional suelen aparecer primero por su relevancia.' 
    },
    
    // Drafter Elements
    'drafter-config': { 
        title: 'Configuración', 
        description: 'Define el tipo de documento y los hechos del caso.', 
        tip: 'Elige correctamente el tipo de documento para que la IA cargue la estructura legal adecuada.' 
    },
    'drafter-result': { 
        title: 'Documento Generado', 
        description: 'El borrador final listo para revisión.', 
        tip: 'Siempre lee el documento. La IA es una herramienta de apoyo, no un reemplazo de tu criterio jurídico.' 
    },
    'drafter-action-print': { 
        title: 'Imprimir / PDF', 
        description: 'Prepara el documento en formato limpio para imprimir o guardar como PDF.', 
        tip: 'El modo impresión elimina los menús y botones, dejando solo el texto legal formal.' 
    },
    'drafter-action-download': { 
        title: 'Descargar TXT', 
        description: 'Descarga el contenido en un archivo de texto plano.', 
        tip: 'Útil si necesitas editar el documento en Word u otro procesador de texto offline.' 
    },
    'drafter-action-copy': { 
        title: 'Copiar Texto', 
        description: 'Copia todo el contenido al portapapeles.', 
        tip: 'Pégalo directamente en tu correo electrónico para enviarlo a revisión de tu cliente.' 
    },
    'drafter-action-clear': { 
        title: 'Limpiar', 
        description: 'Borra el borrador actual para empezar de nuevo.', 
        tip: '¡Cuidado! Esta acción es irreversible. Asegúrate de haber guardado si lo necesitas.' 
    },
    
    // Comparator Elements
    'comparator-inputs': { 
        title: 'Textos a Comparar', 
        description: 'Pega aquí los dos argumentos o sentencias.', 
        tip: 'Funciona mejor con textos de longitud similar (ej. dos párrafos de "Consideraciones").' 
    },
    
    // Library
    'library-folder': { 
        title: 'Carpeta de Expediente', 
        description: 'Contenedor para agrupar documentos de un mismo tema.', 
        tip: 'Usa la carpeta "Jurisprudencia Guardada" para tener a mano tus sentencias hito.' 
    },

    // Calendar
    'calendar-sync': { 
        title: 'Sincronizar', 
        description: 'Conecta Toga con Google Calendar o Outlook.', 
        tip: 'La sincronización bidireccional evita que tengas que agendar dos veces la misma audiencia.' 
    },
    
    // Community
    'community-post-input': { 
        title: 'Crear Publicación', 
        description: 'Espacio para redactar tu duda o aporte.', 
        tip: 'Usa etiquetas (hashtags) como #Penal o #Laboral para que los expertos en esa área te encuentren rápido.' 
    },
    
    // Profile
    'profile-card': { 
        title: 'Tarjeta Profesional', 
        description: 'Tu presentación ante la comunidad Toga.', 
        tip: 'Una buena foto y datos actualizados generan confianza y pueden traerte casos referidos.' 
    },
    'profile-upgrade': { 
        title: 'Plan Premium', 
        description: 'Desbloquea las herramientas avanzadas de IA.', 
        tip: 'El costo de la suscripción suele recuperarse con el tiempo ahorrado en la redacción de una sola tutela.' 
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans">
      {/* New Companion System */}
      <TogadoCompanion knowledgeBase={TOGADO_KNOWLEDGE_BASE} />

      <Sidebar 
        activeView={activeView} 
        onChangeView={setActiveView} 
        isMobileOpen={isMobileOpen}
        toggleMobile={() => setIsMobileOpen(!isMobileOpen)}
      />

      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 z-10 print:hidden">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsMobileOpen(true)}
              className="md:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-semibold text-slate-800 capitalize">
              {activeView === 'drafter' ? 'Redactor IA' : activeView}
            </h2>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
                data-toga-help="header-notifications"
                className="relative p-2 text-slate-400 hover:text-blue-600 transition-colors"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
            </button>
            <div 
                data-toga-help="header-profile"
                className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => setActiveView('profile')}
            >
              <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
                {user.avatarUrl && <img src={user.avatarUrl} alt="User" className="w-full h-full object-cover" />}
              </div>
              <span className="hidden sm:block text-sm font-medium text-slate-700">{user.name}</span>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto h-full">
            {activeView === 'dashboard' && <DashboardView user={user} />}
            {activeView === 'search' && <SearchView />}
            {activeView === 'library' && <LibraryView />}
            {activeView === 'calendar' && <CalendarView />}
            {activeView === 'drafter' && <DrafterView user={user} onUpgrade={() => setShowUpgradeModal(true)} />}
            {activeView === 'comparator' && <ComparatorView user={user} onUpgrade={() => setShowUpgradeModal(true)} />}
            {activeView === 'community' && <CommunityView />}
            {activeView === 'profile' && <ProfileView user={user} onUpgrade={() => setShowUpgradeModal(true)} />}
          </div>
        </div>
      </main>

      {/* Upgrade Modal */}
      <Modal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} title="Plan Premium Toga">
        <div className="text-center">
          <div className="mb-6">
            <h4 className="text-2xl font-bold text-slate-900 mb-2">$89.000 COP / mes</h4>
            <p className="text-slate-500">Acceso ilimitado a herramientas de IA</p>
          </div>
          <ul className="text-left space-y-3 mb-8 text-slate-700">
            <li className="flex items-center gap-2"><Check className="w-5 h-5 text-green-500" /> Redacción ilimitada de documentos</li>
            <li className="flex items-center gap-2"><Check className="w-5 h-5 text-green-500" /> Comparador de sentencias avanzado</li>
            <li className="flex items-center gap-2"><Check className="w-5 h-5 text-green-500" /> Prioridad en soporte</li>
          </ul>
          <Button variant="premium" className="w-full py-3" onClick={handleUpgrade}>
            Pagar con Wompi
          </Button>
        </div>
      </Modal>
    </div>
  );
}

// --- VIEW COMPONENTS ---

const DashboardView = ({ user }: { user: User }) => (
  <div className="space-y-6">
    {/* Welcome Banner */}
    <div id="welcome-banner" data-toga-help="welcome-banner" className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 sm:p-10 text-white shadow-lg relative overflow-hidden">
      <div className="relative z-10">
        <h2 className="text-2xl sm:text-3xl font-bold mb-2">Hola, {user.name}</h2>
        <p className="text-blue-100 opacity-90 max-w-xl mb-6">
          Tienes <span className="font-bold text-white">3 vencimientos</span> esta semana y tu reputación ha subido a <span className="font-bold text-white">{user.reputation} puntos</span>.
        </p>
        
        <div className="flex flex-wrap gap-4">
          {user.role === 'FREE' && (
            <Button variant="secondary" className="bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur-sm">
              Pasar a Premium
            </Button>
          )}
        </div>
      </div>
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-12 translate-x-12 pointer-events-none"></div>
    </div>

    {/* Stats Grid */}
    <div data-toga-help="stats-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {[
        { label: 'Casos Activos', value: '12', color: 'text-blue-600' },
        { label: 'Documentos IA', value: '45', color: 'text-purple-600' },
        { label: 'Audiencias Mes', value: '8', color: 'text-amber-600' },
        { label: 'Reputación', value: user.reputation, color: 'text-green-600' },
      ].map((stat, i) => (
        <Card key={i} className="flex flex-col justify-center items-center py-6">
          <span className={`text-3xl font-bold ${stat.color}`}>{stat.value}</span>
          <span className="text-sm text-slate-500 mt-1">{stat.label}</span>
        </Card>
      ))}
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card title="Expedientes Recientes">
          <div className="space-y-4">
            {MOCK_CASES.slice(0, 3).map(c => (
              <div key={c.id} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-lg transition-colors border border-transparent hover:border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-medium text-slate-900">{c.title}</h4>
                    <p className="text-xs text-slate-500">{c.client} • {c.type}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium 
                  ${c.status === 'Activo' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>
                  {c.status}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div>
        <Card title="Próximos Eventos">
          <div className="space-y-4">
            {MOCK_EVENTS.map(e => (
              <div key={e.id} className="flex gap-3 items-start border-l-4 border-blue-500 pl-3 py-1">
                <div>
                  <h5 className="text-sm font-semibold text-slate-800">{e.title}</h5>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {new Date(e.date).toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  </div>
);

const SearchView = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(JURISPRUDENCE_MOCK_DB);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) {
      setResults(JURISPRUDENCE_MOCK_DB);
      return;
    }
    const filtered = JURISPRUDENCE_MOCK_DB.filter(item => 
      item.title.toLowerCase().includes(query.toLowerCase()) || 
      item.snippet.toLowerCase().includes(query.toLowerCase())
    );
    setResults(filtered);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Buscador Inteligente</h2>
        <p className="text-slate-500">Encuentra jurisprudencia colombiana usando IA semántica.</p>
      </div>
      
      <form onSubmit={handleSearch} className="relative mb-8" data-toga-help="search-input">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ej: 'Sentencias sobre despido sin justa causa en embarazo'..."
          className="w-full pl-12 pr-12 py-4 rounded-xl border border-slate-200 shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
        />
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-6 h-6" />
        <div className="absolute right-24 top-1/2 -translate-y-1/2">
            <VoiceRecorder onResult={(text) => setQuery(prev => prev ? prev + ' ' + text : text)} />
        </div>
        <Button type="submit" className="absolute right-2 top-2 bottom-2">Buscar</Button>
      </form>

      <div className="space-y-4" data-toga-help="search-results">
        {results.map(item => (
          <Card key={item.id} className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-blue-500">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold text-blue-700">{item.title}</h3>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">{item.court}</span>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">{item.snippet}</p>
          </Card>
        ))}
        {results.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            No se encontraron resultados para "{query}". Intenta otros términos.
          </div>
        )}
      </div>
    </div>
  );
};

const DrafterView = ({ user, onUpgrade }: { user: User; onUpgrade: () => void }) => {
  const [type, setType] = useState(DocType.TUTELA);
  const [details, setDetails] = useState('');
  
  // --- Persistence: Draft Result ---
  const [result, setResult] = useState(() => {
    return localStorage.getItem('toga_draft_result') || '';
  });
  
  const [loading, setLoading] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  // Auto-save draft result
  useEffect(() => {
    localStorage.setItem('toga_draft_result', result);
  }, [result]);

  const handleDraft = async () => {
    setLoading(true);
    setResult(''); // Clear previous
    try {
      // Use the stream
      const stream = generateLegalDocumentStream(type, details);
      for await (const chunk of stream) {
        setResult(prev => prev + chunk);
        // Auto-scroll to bottom
        if (resultRef.current) {
          resultRef.current.scrollTop = resultRef.current.scrollHeight;
        }
      }
    } catch (e) {
      alert("Error generando documento");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    alert("Texto copiado al portapapeles");
  };

  const handleDownload = () => {
    // Create a Blob and trigger a download
    const element = document.createElement("a");
    const file = new Blob([result], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `borrador_${type.toLowerCase().replace(/ /g, '_')}.txt`;
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
    document.body.removeChild(element);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleClear = () => {
    if(window.confirm("¿Estás seguro de borrar el borrador?")) {
      setResult('');
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-[calc(100vh-140px)] print:block print:h-auto">
      {/* Settings Panel (Hidden on Print) */}
      <Card title="Configuración del Documento" className="flex flex-col h-full print:hidden">
        <PremiumLock isPremium={user.role === 'PREMIUM'} onUpgrade={onUpgrade}>
          <div className="space-y-6" data-toga-help="drafter-config">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Tipo de Documento</label>
              <select 
                value={type} 
                onChange={(e) => setType(e.target.value as DocType)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500"
              >
                {Object.values(DocType).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                 <label className="block text-sm font-medium text-slate-700">Hechos y Detalles</label>
                 <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">Dictar</span>
                    <VoiceRecorder onResult={(text) => setDetails(prev => (prev ? prev + ' ' : '') + text)} />
                 </div>
              </div>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe los hechos relevantes, fechas, nombres de las partes y pretensiones específicas..."
                className="w-full h-64 p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 resize-none text-sm leading-relaxed"
              />
            </div>
            <Button onClick={handleDraft} isLoading={loading} className="w-full py-3" disabled={!details}>
              {loading ? 'Redactando...' : 'Generar Borrador con IA'}
            </Button>
            <p className="text-xs text-center text-slate-400">
              El borrador se guarda automáticamente en este dispositivo.
            </p>
          </div>
        </PremiumLock>
      </Card>

      {/* Result Panel */}
      <Card className="flex flex-col h-full bg-slate-50 relative p-0 overflow-hidden print:shadow-none print:border-none print:bg-white print:overflow-visible print:h-auto">
        {/* Toolbar (Hidden on Print) */}
        <div className="px-4 py-3 border-b border-slate-200 bg-white flex justify-between items-center sticky top-0 z-10 print:hidden">
          <h3 className="font-semibold text-slate-800">Resultado</h3>
          <div className="flex gap-2">
             <button data-toga-help="drafter-action-print" onClick={handlePrint} title="Imprimir / Guardar PDF" className="p-2 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-100" disabled={!result}>
              <Printer className="w-4 h-4" />
            </button>
            <button data-toga-help="drafter-action-download" onClick={handleDownload} title="Descargar .txt" className="p-2 text-slate-500 hover:text-green-600 rounded hover:bg-green-50" disabled={!result}>
              <FileDown className="w-4 h-4" />
            </button>
            <button data-toga-help="drafter-action-copy" onClick={copyToClipboard} title="Copiar" className="p-2 text-slate-500 hover:text-blue-600 rounded hover:bg-blue-50" disabled={!result}>
              <Copy className="w-4 h-4" />
            </button>
            <button data-toga-help="drafter-action-clear" onClick={handleClear} title="Limpiar" className="p-2 text-slate-400 hover:text-red-500 rounded hover:bg-red-50" disabled={!result}>
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div data-toga-help="drafter-result" ref={resultRef} className="flex-1 p-8 overflow-y-auto bg-white print:p-0 print:overflow-visible">
          {result ? (
            <div id="legal-document-content">
              <MarkdownRenderer content={result} />
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center border-2 border-dashed border-slate-100 rounded-lg m-4 print:hidden">
              <PenTool className="w-12 h-12 mb-4 opacity-30" />
              <p>El documento generado aparecerá aquí.</p>
              <p className="text-xs mt-2 text-slate-300">Usa el panel izquierdo para comenzar.</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

const ComparatorView = ({ user, onUpgrade }: { user: User; onUpgrade: () => void }) => {
  const [textA, setTextA] = useState('');
  const [textB, setTextB] = useState('');
  const [comparison, setComparison] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCompare = async () => {
    setLoading(true);
    try {
      const res = await compareJurisprudence(textA, textB);
      setComparison(res);
    } catch (error) {
      alert("Error en la comparación");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PremiumLock isPremium={user.role === 'PREMIUM'} onUpgrade={onUpgrade}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" data-toga-help="comparator-inputs">
          <Card title="Sentencia / Texto A">
            <textarea
              className="w-full h-40 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 resize-none"
              placeholder="Pega aquí el texto del primer caso..."
              value={textA}
              onChange={(e) => setTextA(e.target.value)}
            />
          </Card>
          <Card title="Sentencia / Texto B">
            <textarea
              className="w-full h-40 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 resize-none"
              placeholder="Pega aquí el texto del segundo caso..."
              value={textB}
              onChange={(e) => setTextB(e.target.value)}
            />
          </Card>
        </div>
        
        <div className="flex justify-center mt-6">
          <Button onClick={handleCompare} isLoading={loading} disabled={!textA || !textB} className="px-8">
            Comparar Jurisprudencia
          </Button>
        </div>

        {comparison && (
          <Card title="Análisis Comparativo IA" className="mt-8 bg-blue-50/50 border-blue-100">
             <MarkdownRenderer content={comparison} />
          </Card>
        )}
      </PremiumLock>
    </div>
  );
};

const CommunityView = () => {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="p-4 bg-white">
        <div className="flex gap-4">
          <div className="w-10 h-10 rounded-full bg-slate-200 flex-shrink-0" />
          <div className="flex-1" data-toga-help="community-post-input">
            <textarea 
              placeholder="Comparte una duda jurídica o un caso de éxito..."
              className="w-full p-2 bg-slate-50 rounded-lg border-transparent focus:bg-white focus:border-slate-300 focus:ring-0 transition-all resize-none h-20"
            />
            <div className="flex justify-between items-center mt-2">
              <label className="flex items-center gap-2 text-sm text-slate-500 cursor-pointer">
                <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" />
                Publicar como anónimo
              </label>
              <Button>Publicar</Button>
            </div>
          </div>
        </div>
      </Card>

      {MOCK_POSTS.map(post => (
        <Card key={post.id} className="p-0">
          <div className="p-4 border-b border-slate-50">
            <div className="flex items-center gap-3 mb-2">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white
                ${post.isAnonymous ? 'bg-slate-400' : 'bg-blue-600'}`}>
                {post.author[0]}
              </div>
              <div>
                <h4 className="font-semibold text-slate-900">{post.author}</h4>
                <p className="text-xs text-slate-500">{post.authorRole} • {post.timestamp}</p>
              </div>
            </div>
            <p className="text-slate-700 leading-relaxed mb-3">{post.content}</p>
            <div className="flex gap-2">
              {post.tags.map(tag => (
                <span key={tag} className="text-xs font-medium px-2 py-1 bg-slate-100 text-slate-600 rounded-full">#{tag}</span>
              ))}
            </div>
          </div>
          <div className="px-4 py-3 bg-slate-50 flex gap-6 text-sm text-slate-500 font-medium">
            <button className="flex items-center gap-2 hover:text-blue-600 transition-colors">
              <ThumbsUp className="w-4 h-4" /> {post.likes}
            </button>
            <button className="flex items-center gap-2 hover:text-blue-600 transition-colors">
              <MessageSquare className="w-4 h-4" /> {post.comments}
            </button>
          </div>
        </Card>
      ))}
    </div>
  );
};

const LibraryView = () => (
  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
    {['Derecho Civil', 'Penal', 'Laboral', 'Familia', 'Contratos', 'Mis Tutelas', 'Jurisprudencia Guardada'].map((folder, i) => (
      <button key={i} data-toga-help="library-folder" className="group p-6 bg-white border border-slate-200 rounded-xl hover:shadow-md hover:border-blue-400 transition-all flex flex-col items-center justify-center text-center gap-3">
        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
          <Library className="w-8 h-8 text-blue-600" />
        </div>
        <span className="font-medium text-slate-700 group-hover:text-blue-700">{folder}</span>
        <span className="text-xs text-slate-400">0 elementos</span>
      </button>
    ))}
  </div>
);

const CalendarView = () => (
  <div className="flex flex-col h-[calc(100vh-140px)]">
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-2xl font-bold">Agenda Judicial</h2>
      <Button variant="outline" data-toga-help="calendar-sync"><CalIcon className="w-4 h-4 mr-2" /> Sincronizar</Button>
    </div>
    <Card className="flex-1 flex items-center justify-center bg-white">
      <div className="text-center text-slate-500 max-w-sm">
        <CalIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Vista de Calendario</h3>
        <p>Aquí se mostraría un calendario mensual completo interactivo con integración a Google Calendar.</p>
        <div className="mt-6 space-y-2 text-left">
          {MOCK_EVENTS.map(e => (
             <div key={e.id} className="p-3 bg-slate-50 rounded border-l-4 border-blue-500 text-sm">
               <div className="font-medium text-slate-900">{e.title}</div>
               <div className="text-slate-500">{new Date(e.date).toLocaleDateString()}</div>
             </div>
          ))}
        </div>
      </div>
    </Card>
  </div>
);

const ProfileView = ({ user, onUpgrade }: { user: User; onUpgrade: () => void }) => (
  <div className="max-w-2xl mx-auto">
    <Card className="mb-6" >
      <div className="flex flex-col items-center text-center p-6" data-toga-help="profile-card">
        <div className="w-24 h-24 rounded-full bg-slate-200 mb-4 overflow-hidden">
           {user.avatarUrl && <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />}
        </div>
        <h2 className="text-2xl font-bold text-slate-900">{user.name}</h2>
        <p className="text-slate-500 mb-4">{user.email}</p>
        <div className="flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-semibold">
           {user.role === 'PREMIUM' ? 'Usuario Premium' : 'Plan Gratuito'}
        </div>
      </div>
      <div className="border-t border-slate-100 p-6 flex justify-around">
         <div className="text-center">
            <div className="text-xl font-bold text-slate-900">{user.reputation}</div>
            <div className="text-xs text-slate-500 uppercase tracking-wide">Reputación</div>
         </div>
         <div className="text-center">
            <div className="text-xl font-bold text-slate-900">145</div>
            <div className="text-xs text-slate-500 uppercase tracking-wide">Casos</div>
         </div>
         <div className="text-center">
            <div className="text-xl font-bold text-slate-900">2.3k</div>
            <div className="text-xs text-slate-500 uppercase tracking-wide">Seguidores</div>
         </div>
      </div>
    </Card>

    {user.role !== 'PREMIUM' && (
      <div data-toga-help="profile-upgrade" className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-8 text-white text-center shadow-xl">
        <h3 className="text-2xl font-bold mb-2">Sube de Nivel tu Práctica Legal</h3>
        <p className="text-slate-300 mb-6">Obtén acceso a todas las herramientas de IA, almacenamiento ilimitado y soporte prioritario.</p>
        <Button variant="premium" onClick={onUpgrade} className="px-8 py-3 text-lg">
          Mejorar a Premium
        </Button>
      </div>
    )}
  </div>
);

export default App;
